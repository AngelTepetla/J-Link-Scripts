# Memory Usage
## Application
### RAM
- 32768 total bytes
- 12479 bytes used (38.08%)
- 20289 bytes free (61.92%)

### ROM
- 237568 total bytes
- 82943 bytes used (34.91%)
- 154625 bytes free (65.09%)

## Boot Loader
### RAM
- 32768 total bytes
- 6282 bytes used (19.17%)
- 26486 bytes free (80.83%)

### ROM
- 20480 total bytes
- 14870 bytes used (72.61%)
- 5610 bytes free (27.39%)

## Parametric
### ROM
- 4096 total bytes
- 1072 bytes used (26.17%)
- 3024 bytes free (73.83%)
